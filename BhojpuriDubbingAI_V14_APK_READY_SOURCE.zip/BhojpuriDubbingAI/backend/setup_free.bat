@echo off
python -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
echo.
echo Install FFmpeg and make sure ffmpeg and ffprobe are in PATH.
echo Install a local LLM runtime (for example Ollama) and a local Bhojpuri TTS server.
echo Then run:
echo python pipeline\dub_movie.py input.mp4 output_bhojpuri.mp4
