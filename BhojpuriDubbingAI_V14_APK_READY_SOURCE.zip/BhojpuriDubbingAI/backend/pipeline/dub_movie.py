#!/usr/bin/env python3
"""Hindi -> Bhojpuri dubbing pipeline with optional advanced features."""
import argparse, json, os, subprocess, shutil, time
from pathlib import Path
from advanced_features import separate_background, diarize, clone_tts, lip_sync

def run(cmd): subprocess.run(cmd, check=True)

def probe_duration(path):
    return float(subprocess.check_output(["ffprobe","-v","error","-show_entries","format=duration","-of","default=noprint_wrappers=1:nokey=1",str(path)], text=True).strip())

def write_status(work, **values):
    work.mkdir(parents=True, exist_ok=True); p=work/"status.json"; old={}
    if p.exists():
        try: old=json.loads(p.read_text(encoding="utf-8"))
        except Exception: pass
    old.update(values, updated_at=time.time()); p.write_text(json.dumps(old,ensure_ascii=False,indent=2),encoding="utf-8")

def chunk_video(src,outdir,minutes):
    outdir.mkdir(parents=True,exist_ok=True); existing=sorted(outdir.glob("chunk_*.mp4"))
    if existing: return existing
    run(["ffmpeg","-y","-i",str(src),"-map","0","-c","copy","-f","segment","-segment_time",str(minutes*60),"-reset_timestamps","1",str(outdir/"chunk_%04d.mp4")])
    return sorted(outdir.glob("chunk_*.mp4"))

class LocalTranslator:
    def __init__(self):
        import requests
        self.requests=requests; self.url=os.getenv("LOCAL_TRANSLATOR_URL","http://127.0.0.1:11434/api/generate"); self.model=os.getenv("LOCAL_TRANSLATOR_MODEL","qwen2.5:3b")
    def translate(self,text):
        prompt="Translate Hindi movie dialogue into natural spoken Bhojpuri. Keep meaning, names, emotion and register. Output only Bhojpuri.\n\n"+text
        if "11434" in self.url:
            r=self.requests.post(self.url,json={"model":self.model,"prompt":prompt,"stream":False},timeout=600); r.raise_for_status(); return r.json().get("response","").strip()
        r=self.requests.post(self.url,json={"text":prompt},timeout=600); r.raise_for_status(); return r.json()["text"].strip()

class LocalTTS:
    def synthesize(self,text,outwav,voice=None):
        voice=voice or os.getenv("BHOJPURI_VOICE","Bhojpuri (Male)")
        if os.getenv("USE_SVARA","1")=="1":
            from svara_tts import synthesize; synthesize(text,str(outwav),voice); return
        import requests
        r=requests.post(os.getenv("LOCAL_TTS_URL","http://127.0.0.1:8000/synthesize"),json={"text":text,"voice":voice,"format":"wav"},timeout=600); r.raise_for_status(); outwav.write_bytes(r.content)

def transcribe(chunk,model,work):
    p=work/"segments.json"
    if p.exists(): return json.loads(p.read_text(encoding="utf-8"))
    segs,_=model.transcribe(str(chunk),language="hi",vad_filter=True,word_timestamps=False)
    data=[{"start":float(s.start),"end":float(s.end),"text":s.text.strip()} for s in segs if s.text.strip()]
    p.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8"); return data

def atempo_filter(ratio):
    filters=[]
    while ratio>2: filters.append("atempo=2.0"); ratio/=2
    while ratio<0.5: filters.append("atempo=0.5"); ratio/=0.5
    filters.append(f"atempo={ratio:.6f}"); return ",".join(filters)

def fit_audio(src,target,out):
    run(["ffmpeg","-y","-i",str(src),"-filter:a",atempo_filter(probe_duration(src)/max(target,0.15)),str(out)])

def load_json(path,default):
    try: return json.loads(Path(path).read_text(encoding="utf-8")) if Path(path).exists() else default
    except Exception: return default

def choose_voice(speaker,voice_map):
    return voice_map.get(str(speaker),voice_map.get("default","Bhojpuri (Male)"))

def synthesize_segment(text,outwav,speaker,advanced,voice_map):
    # Cloning is only attempted when explicitly enabled and an authorized reference exists.
    ref=Path(advanced.get("voice_reference_dir","voice_refs"))/(str(speaker or "SPEAKER_00")+".wav")
    if advanced.get("voice_cloning") and ref.exists() and os.getenv("VOICE_CLONE_BACKEND","none").lower()=="xtts":
        try: return clone_tts(text,outwav,ref,language=advanced.get("tts_language","bho"))
        except Exception as e: write_status(outwav.parent,message=f"Voice cloning fallback: {e}")
    LocalTTS().synthesize(text,outwav,choose_voice(speaker,voice_map))
    return outwav

def mix_timestamped(chunk,segments,work,out,chunk_duration,background_override,advanced,voice_map):
    if not segments: shutil.copy2(chunk,out); return
    wavs=[]
    for i,s in enumerate(segments):
        fitted=work/f"fit_{i:05d}.wav"
        if not fitted.exists():
            raw=work/f"tts_{i:05d}.wav"; synthesize_segment(s["bhojpuri"],raw,s.get("speaker"),advanced,voice_map); fit_audio(raw,max(.15,s["end"]-s["start"]),fitted)
        wavs.append((s,fitted))
    inputs=[]; filters=[]; labels=[]
    for i,(s,wav) in enumerate(wavs):
        inputs += ["-i",str(wav)]; label=f"a{i}"; filters.append(f"[{i}:a]adelay={max(0,int(round(s['start']*1000)))}:all=1[{label}]"); labels.append(f"[{label}]")
    filters.append("".join(labels)+f"amix=inputs={len(labels)}:duration=longest:normalize=0,atrim=0:{chunk_duration:.3f}[dub]")
    mixed=work/"timestamped.wav"
    if not mixed.exists(): run(["ffmpeg","-y",*inputs,"-filter_complex",";".join(filters),"-map","[dub]","-ar","24000","-ac","1",str(mixed)])
    mode=os.getenv("BACKGROUND_MODE","quiet_original").lower()
    if mode=="mute":
        run(["ffmpeg","-y","-i",str(chunk),"-i",str(mixed),"-map","0:v:0","-map","1:a:0","-c:v","copy","-c:a","aac","-t",f"{chunk_duration:.3f}",str(out)]); return
    bg=Path(os.getenv("BACKGROUND_AUDIO","")) if mode=="external" else (Path(background_override) if background_override else work/"background.wav")
    if not bg.exists():
        if mode=="external": raise FileNotFoundError(f"BACKGROUND_AUDIO not found: {bg}")
        run(["ffmpeg","-y","-i",str(chunk),"-vn","-af","volume=0.08","-ar","24000","-ac","2",str(bg)])
    run(["ffmpeg","-y","-i",str(chunk),"-i",str(mixed),"-i",str(bg),"-filter_complex","[1:a]volume=1[d];[2:a]volume=1[b];[d][b]amix=inputs=2:duration=longest:normalize=0[a]","-map","0:v:0","-map","[a]","-c:v","copy","-c:a","aac","-t",f"{chunk_duration:.3f}",str(out)])

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("input"); ap.add_argument("output"); ap.add_argument("--work",default="work"); ap.add_argument("--chunk-minutes",type=int,default=15); ap.add_argument("--whisper",default="small"); args=ap.parse_args()
    src=Path(args.input).resolve(); out=Path(args.output).resolve(); work=Path(args.work).resolve(); work.mkdir(parents=True,exist_ok=True)
    try:
        write_status(work,state="starting",progress=0,input=str(src),output=str(out)); chunks=chunk_video(src,work/"chunks",args.chunk_minutes); total=len(chunks)
        cfg=load_json(os.getenv("ADVANCED_CONFIG",Path(__file__).with_name("advanced_config.json")),{"features":{}}); advanced=cfg.get("features",{})
        voice_map=load_json(work/"character_voices.json",load_json(Path(__file__).with_name("character_voices.json"),{"default":"Bhojpuri (Male)"}))
        write_status(work,state="processing",total_chunks=total,completed_chunks=0,progress=0,message="Processing chunks")
        from faster_whisper import WhisperModel; asr=WhisperModel(args.whisper,device="auto",compute_type="auto"); translator=LocalTranslator(); results=[]
        for n,ch in enumerate(chunks):
            while (work/"PAUSE").exists(): write_status(work,state="paused",current_chunk=n+1,completed_chunks=n,progress=int(n*100/total)); time.sleep(2)
            cw=work/f"part_{n:04d}"; cw.mkdir(exist_ok=True); marker=cw/"done.json"
            if marker.exists(): results.append(Path(load_json(marker,{"output":str(cw/"dubbed.mp4")})["output"])); continue
            cdur=probe_duration(ch); segs=transcribe(ch,asr,cw)
            if advanced.get("speaker_diarization"):
                dp=cw/"speakers.json"; speakers=load_json(dp,[])
                if not speakers:
                    try: speakers=diarize(ch,dp)
                    except Exception as e:
                        if advanced.get("require_diarization",False): raise
                        speakers=[]; write_status(work,message=f"Diarization fallback on chunk {n+1}: {e}")
                for s in segs:
                    matches=[x for x in speakers if x["start"]<s["end"] and x["end"]>s["start"]]
                    if matches: s["speaker"]=max(matches,key=lambda x:min(x["end"],s["end"])-max(x["start"],s["start"]))["speaker"]
            tp=cw/"translated.json"; segs=load_json(tp,segs)
            if not tp.exists():
                for s in segs: s["bhojpuri"]=translator.translate(s["text"])
                tp.write_text(json.dumps(segs,ensure_ascii=False,indent=2),encoding="utf-8")
            bg=None
            if advanced.get("m_and_e_separation"):
                try: bg=separate_background(ch,cw/"separation")
                except Exception as e:
                    if advanced.get("require_m_and_e",False): raise
                    write_status(work,message=f"M&E fallback on chunk {n+1}: {e}")
            outpart=cw/"dubbed.mp4"
            if not outpart.exists(): mix_timestamped(ch,segs,cw,outpart,cdur,bg,advanced,voice_map)
            if advanced.get("lip_sync"):
                ls=cw/"lipsynced.mp4"
                if not ls.exists(): lip_sync(outpart,cw/"timestamped.wav",ls)
                outpart=ls
            marker.write_text(json.dumps({"output":str(outpart)},ensure_ascii=False),encoding="utf-8"); results.append(outpart)
            write_status(work,current_chunk=n+1,completed_chunks=n+1,progress=int((n+1)*100/total),message=f"Chunk {n+1}/{total} complete")
        concat=work/"final.txt"; concat.write_text("\n".join("file '"+p.as_posix().replace("'","'\\''")+"'" for p in results),encoding="utf-8"); run(["ffmpeg","-y","-f","concat","-safe","0","-i",str(concat),"-c","copy",str(out)]); write_status(work,state="done",progress=100,final=str(out))
    except Exception as e: write_status(work,state="error",progress=0,error=f"{type(e).__name__}: {e}"); raise

if __name__=="__main__": main()
