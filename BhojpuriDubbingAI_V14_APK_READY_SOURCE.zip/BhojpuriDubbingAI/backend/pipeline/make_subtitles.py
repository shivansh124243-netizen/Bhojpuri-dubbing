#!/usr/bin/env python3
import argparse, json
from pathlib import Path

def ts(sec):
    ms=max(0,int(round(float(sec)*1000))); h=ms//3600000; ms%=3600000; m=ms//60000; ms%=60000; s=ms//1000; ms%=1000
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('json'); ap.add_argument('srt'); a=ap.parse_args()
    data=json.loads(Path(a.json).read_text(encoding='utf-8')); lines=[]
    for i,x in enumerate(data,1):
        text=x.get('bhojpuri') or x.get('text','');
        if not text: continue
        lines += [str(i), f"{ts(x['start'])} --> {ts(x['end'])}", text, '']
    Path(a.srt).write_text('\n'.join(lines),encoding='utf-8')
if __name__=='__main__': main()
