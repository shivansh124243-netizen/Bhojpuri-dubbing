# Running the dubbing engine

1. Install FFmpeg and Python 3.10+.
2. Install the packages from `requirements.txt`.
3. Run a local Ollama-compatible Hindi→Bhojpuri model at the URL in `.env.example`.
4. Start `python server/server.py` from the `backend` directory.
5. The Android client uploads the movie and polls the job status.

## Natural Bhojpuri voice
Svara-TTS v1 provides dedicated `Bhojpuri (Male)` and `Bhojpuri (Female)` voices. The model is downloaded on first use; its weights are deliberately not bundled in this source archive because they are large.

## Audio modes
`BACKGROUND_MODE=quiet_original` keeps a very low copy of the source audio. It can still contain faint Hindi speech because ordinary FFmpeg cannot separate speech from music/effects.
`BACKGROUND_MODE=mute` gives a clean dialogue-only dub.
For a true clean music/effects track, use a separately prepared M&E/stem as `BACKGROUND_MODE=external` with `BACKGROUND_AUDIO=/path/to/background.wav`.

## Resume
Each 15-minute chunk stores ASR, translation, TTS and a `done.json` marker. If the process stops, completed chunks are reused on restart.
