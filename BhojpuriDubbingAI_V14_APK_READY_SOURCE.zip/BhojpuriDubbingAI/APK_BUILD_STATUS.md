# APK build status

This package is prepared for a GitHub Actions Android build.
The workflow builds `android/app/build/outputs/apk/debug/app-debug.apk` and uploads it as an artifact.

The APK is not claimed as built until the workflow completes successfully and the artifact is verified.
