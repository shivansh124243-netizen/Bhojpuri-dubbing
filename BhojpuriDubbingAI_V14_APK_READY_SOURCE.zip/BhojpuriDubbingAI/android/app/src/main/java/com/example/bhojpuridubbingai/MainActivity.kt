package com.example.bhojpuridubbingai

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.provider.OpenableColumns
import android.widget.*
import androidx.work.*
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
    private lateinit var n: TextView
    private lateinit var p: ProgressBar
    private lateinit var s: TextView
    private var uri: Uri? = null
    private var jobId: String? = null
    private var paused = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        if (android.os.Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
        n = findViewById(R.id.name)
        p = findViewById(R.id.progress)
        s = findViewById(R.id.status)
        findViewById<Spinner>(R.id.voice).adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Bhojpuri (Male)", "Bhojpuri (Female)"))
        jobId = getSharedPreferences("dub", MODE_PRIVATE).getString("job", null)

        findViewById<Button>(R.id.select).setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "video/*"
                addCategory(Intent.CATEGORY_OPENABLE)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }, 9)
        }
        findViewById<Button>(R.id.start).setOnClickListener { startJob() }
        findViewById<Button>(R.id.pause).setOnClickListener { togglePause() }
    }

    private fun server(): String = findViewById<EditText>(R.id.server).text.toString().trim().ifBlank { "http://192.168.1.10:8765" }.trimEnd('/')

    private fun startJob() {
        val u = uri ?: run { toast("पहले वीडियो चुनिए"); return }
        val voice = findViewById<Spinner>(R.id.voice).selectedItem.toString()
        val req = OneTimeWorkRequestBuilder<DubbingWorker>()
            .setInputData(workDataOf("uri" to u.toString(), "voice" to voice, "server" to server()))
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueueUniqueWork("movie-dubbing", ExistingWorkPolicy.REPLACE, req)
        WorkManager.getInstance(this).getWorkInfoByIdLiveData(req.id).observeForever { w ->
            if (w != null) {
                p.progress = w.progress.getInt("p", 0)
                s.text = w.progress.getString("status") ?: w.state.name
                jobId = w.progress.getString("job") ?: jobId
                if (w.state == WorkInfo.State.SUCCEEDED) toast("डबिंग पूरी हुई: Movies/BhojpuriDubbing")
                if (w.state == WorkInfo.State.FAILED) toast(w.outputData.getString("error") ?: "डबिंग में त्रुटि")
            }
        }
    }

    private fun togglePause() {
        val job = jobId ?: run { toast("अभी कोई job नहीं है"); return }
        val endpoint = if (paused) "/resume/$job" else "/pause/$job"
        Thread {
            try {
                val c = URL(server() + endpoint).openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 10000
                c.readTimeout = 10000
                c.inputStream.close()
                c.disconnect()
                paused = !paused
                runOnUiThread { findViewById<Button>(R.id.pause).text = if (paused) "▶ Resume" else "⏸ Pause" }
            } catch (_: Exception) { runOnUiThread { toast("Server से संपर्क नहीं हुआ") } }
        }.start()
    }

    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d)
        if (r == 9 && c == RESULT_OK) d?.data?.let { u ->
            uri = u
            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { x ->
                if (x.moveToFirst()) n.text = x.getString(0)
            }
        }
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
}
