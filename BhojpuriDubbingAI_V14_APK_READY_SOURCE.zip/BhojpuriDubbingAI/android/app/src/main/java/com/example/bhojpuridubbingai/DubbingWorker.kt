package com.example.bhojpuridubbingai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.ContentValues
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.delay
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class DubbingWorker(private val ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    private val base get() = inputData.getString("server")!!.trimEnd('/')

    private fun fg(progress: Int, text: String): ForegroundInfo {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("dub", "Bhojpuri Dubbing", NotificationManager.IMPORTANCE_LOW))
        }
        val n: Notification = NotificationCompat.Builder(ctx, "dub")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Bhojpuri Dubbing AI")
            .setContentText(text)
            .setProgress(100, progress.coerceIn(0, 100), false)
            .setOngoing(true)
            .build()
        return if (Build.VERSION.SDK_INT >= 29) {
            ForegroundInfo(1001, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            ForegroundInfo(1001, n)
        }
    }

    private fun post(path: String) {
        val c = URL("$base$path").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 15000
        c.connect()
        c.inputStream.close()
        c.disconnect()
    }

    override suspend fun doWork(): Result {
        return try {
            setForeground(fg(0, "वीडियो अपलोड हो रहा है…"))
            val uri = Uri.parse(inputData.getString("uri")!!)
            val voice = inputData.getString("voice") ?: "Bhojpuri (Male)"
            val encodedVoice = URLEncoder.encode(voice, "UTF-8")
            val conn = URL("$base/upload?voice=$encodedVoice").openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 30000
            conn.readTimeout = 120000
            conn.setRequestProperty("Content-Type", "video/mp4")
            ctx.contentResolver.openInputStream(uri)!!.use { input ->
                conn.outputStream.use { output ->
                    val buffer = ByteArray(1024 * 1024)
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        output.write(buffer, 0, count)
                    }
                }
            }
            if (conn.responseCode !in 200..299) return Result.retry()
            val job = org.json.JSONObject(conn.inputStream.bufferedReader().readText()).getString("job_id")
            ctx.getSharedPreferences("dub", Context.MODE_PRIVATE).edit().putString("job", job).apply()

            while (true) {
                if (isStopped) return Result.retry()
                val statusConn = URL("$base/status/$job").openConnection() as HttpURLConnection
                statusConn.connectTimeout = 15000
                statusConn.readTimeout = 30000
                val j = org.json.JSONObject(statusConn.inputStream.bufferedReader().readText())
                statusConn.disconnect()
                val pct = j.optInt("progress", 0)
                val state = j.optString("state", "processing")
                val message = j.optString("message", state)
                setProgress(workDataOf("p" to pct, "status" to message, "job" to job))
                setForeground(fg(pct, message))
                if (state == "done") break
                if (state == "error") return Result.failure(workDataOf("error" to j.optString("error", message)))
                delay(3000)
            }

            val outName = "Bhojpuri_${System.currentTimeMillis()}.mp4"
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, outName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/BhojpuriDubbing")
            }
            val out = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return Result.failure()
            ctx.contentResolver.openOutputStream(out)!!.use { os ->
                URL("$base/download/$job").openStream().use { it.copyTo(os, 1024 * 1024) }
            }
            ctx.getSharedPreferences("dub", Context.MODE_PRIVATE).edit().remove("job").apply()
            Result.success(workDataOf("status" to "डबिंग पूरी हुई", "output" to outName))
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
